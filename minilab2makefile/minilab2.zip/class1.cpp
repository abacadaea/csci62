#include <string>
#include "class1.h"

Class1::Class1 () { }
Class1::Class1 (int x_) { x = x_; }
int Class1::getX () { return x; }
