#include <iostream>
#include <string>

class Counter {
  private:
    int count;
  public:
    Counter();
    void add();
    int getCount();
};
