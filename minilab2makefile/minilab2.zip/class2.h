#ifndef CLASS2
#define CLASS2

#include <string>

class Class2 {
  private:
    std::string s;
  public:
    Class2 ();
    Class2 (std::string s_);
    std::string getS ();
};

#endif
