#ifndef CLASS1
#define CLASS1

class Class1 {
  private:
    int x;
  public:
    Class1 ();
    Class1 (int x_);
    int getX ();
};

#endif
