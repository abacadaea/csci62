#ifndef MY_CLASS
#define MY_CLASS

class MyClass {
  private:
    int x;
  public:
    MyClass();
    MyClass(int x_);
    int getX();
};

#endif
